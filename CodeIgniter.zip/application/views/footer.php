<!-- PIE DE PAGINA -->
<footer class="container-fluid bg-4 text-center">
  <p>Pagina cine todos los derechos reservados</p>
  <p>Página creada en <strong>{elapsed_time}</strong> segundos. 
  <?php echo  (ENVIRONMENT === 'development') ?  'Versión de CodeIgniter <strong>' . CI_VERSION . '</strong>' : '' ;
  ?>
</footer>

</body>
</html>