<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Cine Si</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css?family=Bungee+Inline" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Faster+One" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Faster+One|Frijole" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Faster+One|Frijole|Monoton" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Roboto+Mono" rel="stylesheet"> 


  <link href="https://fonts.googleapis.com/css?family=Cinzel" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Cinzel|Sintony" rel="stylesheet"> 

  <link href="https://fonts.googleapis.com/css?family=Atomic+Age" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Acme" rel="stylesheet"> 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/estilos.css"/>
   <script type = 'text/javascript' src = "<?php echo base_url(); ?>js/java.js"></script>
  
</head>
<body>

 <header >

     <img  id="menu" src="<?php echo base_url();?>imagenes/menu.png"> 
   
    
        <p class="logo"><span>C</span>ine <span>S</span>i</P>

     

 
