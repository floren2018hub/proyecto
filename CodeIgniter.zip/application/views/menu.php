 
    <nav  id="navegador" style="background-color:black;" >
          
<div class="container-fluid">
    <ul class="nav navbar-nav">
       <li><a href="<?php echo site_url();?>/cine_controller/" style="font-family: 'Roboto Mono', monospace;">Inicio</a></li>
      <li><a href="<?php echo site_url();?>/cine_controller/cartelera " style="font-family: 'Roboto Mono', monospace;">Cartelera</a></li>
      <li><a href="<?php echo site_url();?>/cine_controller/venta" style="font-family: 'Roboto Mono', monospace;">Venta Anticipada</a></li>
      <li><a href="<?php echo site_url();?>/cine_controller/contacto" style="font-family: 'Roboto Mono', monospace;">Contacto</a></li>
    </ul>
 </div>
</nav>
      
    

</header>
