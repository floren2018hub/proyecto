<!-- PIE DE PAGINA -->
<footer class="container-fluid bg-4 text-center">
  <p>© copyright 2018 - Granada, la ciudad paraiso</p>
  <p>Página creada en <strong>{elapsed_time}</strong> segundos. 
  <?php echo  (ENVIRONMENT === 'development') ?  'Versión de CodeIgniter <strong>' . CI_VERSION . '</strong>' : '' ;
  ?>
</footer>

</body>
</html>