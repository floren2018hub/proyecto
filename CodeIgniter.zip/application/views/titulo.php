
<div id="contenedorGeneral" class="cuerpo">

  <h3 class="titulo3" id="titulo"><?php echo $title; ?></h3>
  